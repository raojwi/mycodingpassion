SongNameCleaner v1.0

It will cut the numbering and remove some words like "mix", "remaster", etc. and some special characters.

Step 1: Select the folder containing the songs
Step 2: Wait for the renaming to begin
Step 3: Press Enter to exit
