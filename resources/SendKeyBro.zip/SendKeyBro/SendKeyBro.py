import pyautogui
import turtle

first_key = turtle.textinput("First key", "First key")
print(first_key)
second_key = turtle.textinput("Second key", "Second key")
print(second_key)
number_of_reps = int(turtle.textinput("Number of reps", "Number of reps"))

i = 1
while i <= number_of_reps:
    pyautogui.hotkey(str(first_key), str(second_key))
    i += 1
